from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import re
from django.contrib.auth.backends import ModelBackend
from django.db.models import Q
from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import login, authenticate, logout
from django.views.generic.base import View  # 继承视图的基类
from booking.models import AirRoutes
from booking.models import User
import random


class CustomBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            # 不希望用户存在两个，get只能有一个。两个是get失败的一种原因 Q为使用并集查询
            user = User.objects.get(
                Q(username=username) | Q(email=username) | Q(mobile=username))
            print(user)
            print(username)
            if user.check_password(password):
                return user
        except Exception as e:
            return None


# # Create your views here.
# def user_login(request):
#     mobile = request.GET.get("mobile")
#     password = request.GET.get("password")
#     print(mobile, password)
#     back_data = {
#         "status": 1,
#         "data": {
#             "id": 1,
#             "mobile": 18888888888,
#             "nickname": 'Leo yo',
#             "portrait": 'http://img.61ef.cn/news/201409/28/2014092805595807.jpg'
#         },
#         "msg": '提示'
#     }
#     return JsonResponse(back_data, safe=False)


class LoginView(View):
    """ 登录的验证类"""

    def get(self, request):

        back_data = None
        mobile = request.GET.get("mobile")
        password = request.GET.get("password")
        print(mobile, "+", password)
        # 校验数据的完整性
        if not all([mobile, password]):
            back_data = {
                "status": 0,
                "data": {
                    "id": 1,
                    "mobile": 18888888888,
                    "nickname": 'Leo yo',
                    "portrait": 'http://img.61ef.cn/news/201409/28/2014092805595807.jpg'
                },
                "msg": '请输入手机号和密码'
            }
        else:
            exist_user = User.objects.filter(mobile=mobile) or User.objects.filter(email=mobile)  # 账号是否存在
            print(exist_user)
            user = authenticate(request, username=mobile, password=password)  # 验证登录
            print(user)
            if exist_user:
                if user:
                    data = User.objects.filter(mobile=mobile)
                    for i in data:
                        back_data = {
                            "status": 1,
                            "data": {
                                "id": i.id,
                                "mobile": i.mobile,
                                "nickname": i.username,
                                "portrait": 'http://img.61ef.cn/news/201409/28/2014092805595807.jpg'
                            },
                            "msg": '成功'
                        }
                    login(request, user)
                else:
                    back_data = {
                        "status": 0,
                        "data": {
                            "id": 1,
                            "mobile": 18888888888,
                            "nickname": 'Leo yo',
                            "portrait": 'http://img.61ef.cn/news/201409/28/2014092805595807.jpg'
                        },
                        "msg": '用户名密码错误'
                    }
            else:
                back_data = {
                    "status": 0,
                    "data": {
                        "id": 1,
                        "mobile": 18888888888,
                        "nickname": 'Leo yo',
                        "portrait": 'http://img.61ef.cn/news/201409/28/2014092805595807.jpg'
                    },
                    "msg": '账号不存在'
                }
        return JsonResponse(back_data, safe=False)


class RegisterView(View):
    """ 注册"""

    def get(self, request):
        """ 注册的逻辑实现"""
        mobile = request.GET.get('mobile')
        password = request.GET.get('password')
        agpwd = request.GET.get('agpwd')
        verification = request.GET.get('captchaImg')
        captchaImg = verification.upper()
        veri = 'YFX5'
        try:
            exist_username = User.objects.get(mobile=mobile)
        except User.DoesNotExist:
            # 用户名不存在
            exist_username = None
        if all([mobile, password, agpwd, verification]):  # 判断是否输入完全
            if captchaImg == veri:
                if exist_username is None:
                    if password == agpwd:
                        if re.match(r'^1[0-9]{10}$', mobile):
                            flag_mobile = User.objects.filter(mobile=mobile).values()
                            print(flag_mobile)
                            if flag_mobile:
                                msg = """该用户已存在"""
                                status = 2
                                data_info = {
                                    "status": status,
                                    "msg": msg
                                }
                            else:
                                H = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
                                username = ''
                                for i in range(5):
                                    username += random.choice(H)
                                print(username)  # 随机生成的五位用户名
                                user = User.objects.create_user(username=username, password=password, mobile=mobile)
                                user.is_active = 1
                                user.save()
                                current_user = User.objects.filter(mobile=mobile)[0]
                                msg = """注册成功"""
                                status = 1
                                data_info = {
                                    "status": status,
                                    "data": {
                                        "id": current_user.id,
                                        "mobile": current_user.mobile,
                                        "nickname": current_user.username,
                                        "portrait": '/static/missing-face.png'
                                    },
                                    "msg": msg
                                }
                        else:
                            status = 0
                            msg = """手机号格式不正确"""
                            data_info = {
                                "status": status,
                                "msg": msg
                            }
                    else:
                        status = 0
                        msg = """两次输入密码不一致"""
                        data_info = {
                            "status": status,
                            "msg": msg
                        }
                else:
                    status = 0
                    msg = """ 该用户名已存在"""
                    data_info = {
                        "status": status,
                        "msg": msg
                    }
            else:
                msg = """验证码错误"""
                status = 0
                data_info = {
                    "status": status,
                    "msg": msg
                }
        else:
            status = 0
            msg = """用户信息不完整"""
            data_info = {
                "status": status,
                "msg": msg
            }
        return JsonResponse(data_info, safe=False)
