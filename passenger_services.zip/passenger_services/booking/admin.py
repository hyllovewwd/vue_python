from django.contrib import admin
from booking import models


# Register your models here.
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'mobile', 'qq', 'weChat')


class OrderAdmin(admin.ModelAdmin):
    list_display = ('order_no', 'price', 'info', 'user', 'status')


admin.site.register(models.User, UserAdmin)
admin.site.register(models.Order_air, OrderAdmin)
admin.site.register(models.AirRoutes)
admin.site.register(models.AirCompany)
admin.site.register(models.AirIntroduction)
admin.site.register(models.Discount)
