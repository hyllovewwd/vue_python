from django.urls import path
from booking import views

urlpatterns = [
    path("test/", views.test_api),
    path("regetinfo/", views.regetinfo),
    path("createOrder/",views.createOrder),
    path("payOrder/",views.payOrder),
    path("getOrderInfo/",views.getOrderInfo)
]
