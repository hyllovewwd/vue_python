from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class User(AbstractUser):
    """
    用户表
    """
    mobile = models.CharField("手机号", max_length=128, unique=True)
    weChat = models.CharField("微信", max_length=128)
    identity_number = models.CharField("身份证号", max_length=256)
    qq = models.CharField("qq", max_length=128)
    image_url = models.CharField("头像", max_length=128)

    class Meta:
        db_table = 'myuser'
        verbose_name = '用户'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.username


class AirCompany(models.Model):
    """
    航空公司表
    """
    name = models.CharField("名称", max_length=128)

    class Meta:
        db_table = 'AirCompany'
        verbose_name = '航空公司'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class AirIntroduction(models.Model):
    """
    飞机简介
    """
    name = models.CharField("名称", max_length=128)
    first_class_number = models.IntegerField("头等舱数量")
    economy_class_number = models.IntegerField("经济舱数量")
    content = models.TextField("简介", max_length=512, blank=True)

    class Meta:
        db_table = 'AirIntroduction'
        verbose_name = '飞机类型'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class AirRoutes(models.Model):
    """
    航班线路
    """
    air_no = models.CharField("飞机编号", max_length=128, unique=True)
    start_day = models.CharField("起飞日期", max_length=256)
    stop_day = models.CharField("落地日期", max_length=256)
    start_time = models.CharField("起飞具体时间", max_length=128)
    stop_time = models.CharField("落地具体时间", max_length=128)
    start_airport = models.CharField("起飞机场", max_length=128)
    stop_airport = models.CharField("落地机场", max_length=128)
    place_start = models.CharField("起飞地", max_length=128)
    place_stop = models.CharField("终点地", max_length=128)
    air_company = models.ForeignKey("AirCompany", verbose_name="航空公司", on_delete=models.CASCADE)
    air_type = models.ForeignKey("AirIntroduction", verbose_name="飞机简介", on_delete=models.CASCADE)
    first_class_price = models.IntegerField("头等舱价格")
    economy_class_price = models.IntegerField("经济舱价格")

    class Meta:
        db_table = 'routes'
        verbose_name = '航线'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.air_no


class Discount(models.Model):
    """
    优惠折扣定义表
    """
    discount = models.IntegerField("折数", help_text="例如5,代表5折")
    content = models.TextField("优惠详情", blank=True)

    class Meta:
        db_table = 'discount_db'
        verbose_name = '折扣'
        verbose_name_plural = verbose_name


class Order_air(models.Model):
    """
    订单
    """
    order_no = models.IntegerField("订单编号", unique=True)
    price = models.IntegerField("单价")
    number = models.IntegerField("数量")
    sum_price = models.IntegerField("支付金额")
    info = models.ForeignKey("AirRoutes", verbose_name="航班信息", on_delete=models.CASCADE)
    user = models.ForeignKey("User", verbose_name="用户信息", on_delete=models.CASCADE)
    # youhui = models.ForeignKey("Discount", verbose_name="优惠", on_delete=models.CASCADE, default="无")
    order_status = ((0, '已支付'), (1, '未付款'), (2, '取消付款'))
    status = models.CharField("订单状态", choices=order_status, null=True, max_length=128)
    Passengers = models.ForeignKey("PassengersInfo", on_delete=models.CASCADE)
    pay_type = models.IntegerField("支付方式", help_text="0:微信，1：支付宝", default=None)


class PassengersInfo(models.Model):
    """ 乘客表"""
    name = models.CharField("姓名", max_length=128)
    identity_number = models.CharField("身份证号", max_length=512)
    mobile = models.CharField("手机号", max_length=256)
    desc = models.CharField("留言", max_length=512)
    user=models.ForeignKey("User",on_delete=models.CASCADE)
