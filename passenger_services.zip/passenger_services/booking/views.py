from django.http import JsonResponse, HttpResponse
import datetime
from booking.models import AirRoutes
from booking.models import PassengersInfo, Order_air
import time


def test_api(request):
    air_info_back = []
    start_place = request.GET.get("start_place")
    stop_place = request.GET.get("stop_place")
    flag = request.GET.get("flag")  #
    print(flag)
    back_data = AirRoutes.objects.filter(place_start=start_place, place_stop=stop_place)
    for i in back_data:
        air_no_company = i.air_company.name + i.air_no
        first_class_number = i.air_type.first_class_number  # 头等舱数量
        economy_class_number = i.air_type.economy_class_number  # 经济舱数量
        first_class_price = i.first_class_price  # 头等舱价格
        economy_class_price = i.economy_class_price  # 经济舱价格
        if int(flag) == 0:
            price = economy_class_price
            number = economy_class_number
            position = "经济舱"
        else:
            price = first_class_price
            number = first_class_number
            position = "头等舱"
        start_time = i.start_time
        stop_time = i.stop_time
        s_start_time = datetime.datetime.strptime(start_time, '%H:%M')
        s_stop_time = datetime.datetime.strptime(stop_time, '%H:%M')
        time_sub = s_stop_time - s_start_time
        print(str(time_sub).split(":")[:2])
        time_sub = str(time_sub).split(":")[0] + ":" + str(time_sub).split(":")[1]
        date = {
            "id": i.id,
            "air_no_company": air_no_company,
            "start_day": i.start_day,
            "stop_day": i.stop_day,
            "start_time": i.start_time,
            "stop_time": i.stop_time,
            "start_airport": i.start_airport,
            "stop_airport": i.stop_airport,
            "air_type": i.air_type.name,
            "price": price,
            "number": number,
            "position": position,
            "time_sub": time_sub
        }
        air_info_back.append(date)
    return JsonResponse(air_info_back, safe=False)


def regetinfo(request):
    id = request.GET.get("id")
    flag = request.GET.get("flag")
    air_info_back = []
    back_data = AirRoutes.objects.filter(id=id)
    print(back_data)
    for i in back_data:
        xq = datetime.datetime.today().weekday()
        print("xq:", xq)
        air_no_company = i.air_company.name + i.air_no
        first_class_number = i.air_type.first_class_number  # 头等舱数量
        economy_class_number = i.air_type.economy_class_number  # 经济舱数量
        first_class_price = i.first_class_price  # 头等舱价格
        economy_class_price = i.economy_class_price  # 经济舱价格
        if int(flag) == 0:
            price = economy_class_price
            number = economy_class_number
            position = "经济舱"
        else:
            price = first_class_price
            number = first_class_number
            position = "头等舱"
        start_time = i.start_time
        stop_time = i.stop_time
        s_start_time = datetime.datetime.strptime(start_time, '%H:%M')
        s_stop_time = datetime.datetime.strptime(stop_time, '%H:%M')
        time_sub = s_stop_time - s_start_time
        print(str(time_sub).split(":")[:2])
        time_sub = str(time_sub).split(":")[0] + ":" + str(time_sub).split(":")[1]
        date = {
            "id": i.id,
            "air_no_company": air_no_company,
            "start_day": i.start_day,
            "stop_day": i.stop_day,
            "start_time": i.start_time,
            "stop_time": i.stop_time,
            "start_airport": i.start_airport,
            "stop_airport": i.stop_airport,
            "air_type": i.air_type.name,
            "price": price,
            "number": number,
            "position": position,
            "time_sub": time_sub
        }
        air_info_back.append(date)
    return JsonResponse(air_info_back, safe=False)


def createOrder(request):
    send_number = request.GET.get("send_number")
    send_price = request.GET.get("send_price")
    send_sum_price = request.GET.get("send_sum_price")
    send_name = request.GET.get("send_name")
    send_mobile = request.GET.get("send_mobile")
    send_identity_number = request.GET.get("send_identity_number")
    user_id = int(request.GET.get("user_id"))
    route_id = request.GET.get("route_id")
    send_desc = request.GET.get("send_desc")
    payType = request.GET.get("payType")
    print("user_id:", user_id)
    print(send_number,
          send_price,
          send_sum_price,
          send_name,
          send_mobile,
          send_identity_number,
          user_id,
          route_id,
          send_desc,
          payType
          )
    print(send_name, send_mobile, send_identity_number)
    print(send_desc)
    print(type(send_desc))
    current_time = (lambda: int(round(time.time() * 1000)))
    time_ = current_time()
    print(str(time_)[:10])
    order_no = str(time_)[:10]  # 订单号
    if all([send_name, send_mobile, send_identity_number]):
        p = PassengersInfo.objects.create(name=send_name, identity_number=send_identity_number, mobile=send_mobile,
                                          desc=send_desc, user_id=user_id)
        P_id = p.id  # 当前用户的id
        print(P_id)
        order = Order_air.objects.create(order_no=order_no, price=send_price, number=send_number,
                                         sum_price=send_sum_price, info_id=route_id, user_id=user_id, status=1,
                                         Passengers_id=P_id, pay_type=payType)
        print(order.id)
        back_data = {
            "status": 1,
            "id": order.id,
            "msg": "订单创建成功"
        }
    else:
        back_data = {
            "status": 0,
            "msg": "用户信息填写不完整"
        }
    return JsonResponse(back_data, safe=False)


def payOrder(request):
    order_id = request.GET.get("id")
    payType = request.GET.get("payType")
    sum_price = request.GET.get("price")
    flag = Order_air.objects.filter(id=order_id).update(pay_type=payType, sum_price=sum_price, status=0)
    if flag:
        back_data = {
            "status": 1,
            "msg": "支付成功"
        }
    else:
        back_data = {
            "status": 0,
            "msg": "网络超时"
        }
    return JsonResponse(back_data, safe=False)


def getOrderInfo(request):
    user_id = request.GET.get("id")
    print(user_id)
    pay = []
    no_pay = []
    cancel = []
    sum_order = []
    info = Order_air.objects.filter(user_id=user_id)
    for i in info:
        j = i.info
        air_no_company = j.air_company.name + j.air_no
        first_class_price = j.first_class_price  # 头等舱价格
        economy_class_price = j.economy_class_price  # 经济舱价格
        if i.price == first_class_price:
            position = "头等舱"
        else:
            position = "经济舱"
        start_time = j.start_time
        stop_time = j.stop_time
        s_start_time = datetime.datetime.strptime(start_time, '%H:%M')
        s_stop_time = datetime.datetime.strptime(stop_time, '%H:%M')
        time_sub = s_stop_time - s_start_time
        print(str(time_sub).split(":")[:2])
        time_sub = str(time_sub).split(":")[0] + ":" + str(time_sub).split(":")[1]
        if int(i.status) == 0:
            date = {
                "id": i.id,
                "order_no": i.order_no,
                "price": i.price,
                "status": i.status,
                "number": i.number,
                "sum_price": i.sum_price,
                "pay_type": i.pay_type,
                "info_id": i.info_id,
                "user_id": i.user_id,
                "Passengers_id": i.Passengers_id,
                "air_no": i.info.air_no,
                "air_no_company": air_no_company,
                "start_day": j.start_day,
                "stop_day": j.stop_day,
                "start_time": j.start_time,
                "stop_time": j.stop_time,
                "start_airport": j.start_airport,
                "stop_airport": j.stop_airport,
                "air_type": j.air_type.name,
                "position": position,
                "time_sub": time_sub,
                "name": i.Passengers.name,
                "mobile": i.Passengers.mobile,
            }
            pay.append(date)
        if int(i.status) == 1:
            date = {
                "id": i.id,
                "order_no": i.order_no,
                "price": i.price,
                "status": i.status,
                "number": i.number,
                "sum_price": i.sum_price,
                "pay_type": i.pay_type,
                "info_id": i.info_id,
                "user_id": i.user_id,
                "Passengers_id": i.Passengers_id,
                "air_no": i.info.air_no,
                "air_no_company": air_no_company,
                "start_day": j.start_day,
                "stop_day": j.stop_day,
                "start_time": j.start_time,
                "stop_time": j.stop_time,
                "start_airport": j.start_airport,
                "stop_airport": j.stop_airport,
                "air_type": j.air_type.name,
                "position": position,
                "time_sub": time_sub,
                "name": i.Passengers.name,
                "mobile": i.Passengers.mobile,
            }
            no_pay.append(date)
        if int(i.status) == 2:
            date = {
                "id": i.id,
                "order_no": i.order_no,
                "price": i.price,
                "status": i.status,
                "number": i.number,
                "sum_price": i.sum_price,
                "pay_type": i.pay_type,
                "info_id": i.info_id,
                "user_id": i.user_id,
                "Passengers_id": i.Passengers_id,
                "air_no": i.info.air_no,
                "air_no_company": air_no_company,
                "start_day": j.start_day,
                "stop_day": j.stop_day,
                "start_time": j.start_time,
                "stop_time": j.stop_time,
                "start_airport": j.start_airport,
                "stop_airport": j.stop_airport,
                "air_type": j.air_type.name,
                "position": position,
                "time_sub": time_sub,
                "name": i.Passengers.name,
                "mobile": i.Passengers.mobile,
            }
            cancel.append(date)
    sum_order.append(pay)
    sum_order.append(no_pay)
    sum_order.append(cancel)
    return JsonResponse(sum_order, safe=False)
