<template>
	<view class="content">
		<view class="navbar">
			<view v-for="(item, index) in navList" :key="index" class="nav-item" :class="{current: tabCurrentIndex === index}"
			 @click="tabClick(index)">
				{{item.text}}
			</view>
		</view>
		<view v-if="!hasLogin" >
			<view style="padding-top: 200rpx;text-align: center;">当前未登录</view>
			<view @click="tologin()" style="text-align: center;color: red;">点击去登陆></view>
		</view>
		<swiper :current="tabCurrentIndex" class="swiper-box" duration="300" @change="changeTab">
			<swiper-item class="tab-content" v-for="(tabItem,tabIndex) in navList" :key="tabIndex">
				<scroll-view class="list-scroll-content" scroll-y @scrolltolower="loadData">
					<!-- 空白页 -->
					<empty v-if="tabItem.loaded === true && tabItem.orderList.length === 0"></empty>
					<!-- 订单列表 -->
					<view v-if="hasLogin">
						<view v-for="(items,index) in tabItem.orderList" :key="index" class="order-item">
							<!-- {{item}} -->
							<view style="margin-top: 50rpx;">
								<view class='list_air' v-for="(item, index) in items" :key="item.id">
									<view class="air_info">
										<view class="left_con">
											<view class="time_info">
												<view class="start_time">
													<view style="margin-left: 10rpx;font-size: 30rpx;padding-top: 20rpx;">
														<text style="padding-left: 15rpx;">{{item.start_time}}</text>
														<view>{{item.start_airport}}</view>
													</view>
												</view>
												<view class="float_time">
													<view class="img">
														<view style="margin-left: 10rpx;font-size: 30rpx;padding-top: 20rpx;">
															<view style="padding-left: 10rpx;">用时：{{item.time_sub}}</view>
															<text>-----------></text>
														</view>
													</view>
													<view class="stop_time">
														<view style="margin-left: 10rpx;font-size: 30rpx;padding-top: 20rpx;">
								
															<text style="padding-left: 15rpx;">{{item.stop_time}}</text>
															<view>{{item.stop_airport}}</view>
														</view>
													</view>
												</view>
											</view>
											<view class="air_content">
												<text style="" class="content_text">{{item.air_no_company}} | {{item.air_type}}</text>
											</view>
										</view>
										<view class="right_con">
											<view class="pirze_info">
												<view style="padding-top: 30rpx;text-align: center;">￥{{item.price}}</view>
												<view style="text-align: center;">{{item.position}}</view>
											</view>
											<view class="sale_btn">
												<view style="padding-top: 5rpx;text-align: center;">
													<view v-if="tabCurrentIndex==1">
														<button style="height: 50rpx;font-size: 18rpx;line-height: 50rpx;text-align: center;padding-right: 25rpx;" type="warn" @click="buy(item.id,item.sum_price)">立即支付</button>
													</view>
													<view v-if="tabCurrentIndex==0">
														<view style="height: 50rpx;font-size: 20rpx;line-height: 50rpx;background-color: red;border-radius: 25rpx;">待出行</view>
													</view>
													<view v-if="tabCurrentIndex==2">
														<view style="height: 50rpx;font-size: 20rpx;line-height: 50rpx;background-color: red;border-radius: 25rpx;">已完成</view>
													</view>
												</view>
											</view>
										</view>
									</view>
									<view class="other_fun">
										<view class="tourism_programme">
											<view style="width: 100%;height: 80rpx;line-height: 80rpx;padding-left: 10rpx;border-radius: 40rpx;padding-top: 10rpx;padding-right: 10rpx;">
												<button style="text-align: center;font-size: 25rpx;">旅游方案</button>
											</view>
										</view>
										<view class="right_fun">
											<view class="strategy">
												<view style="width: 100%;height: 80rpx;line-height: 80rpx;padding-left: 10rpx;border-radius: 40rpx;padding-top: 10rpx;padding-right: 10rpx;">
													<button style="text-align: center;font-size: 25rpx;">攻略</button>
												</view>
											</view>
											<view class="road_map">
												<view style="width: 100%;height: 80rpx;line-height: 80rpx;padding-left: 10rpx;border-radius: 40rpx;padding-top: 10rpx;padding-right: 10rpx;">
													<button style="text-align: center;font-size: 25rpx;">地图</button>
												</view>
											</view>
										</view>
									</view>
								</view>
							</view>
						</view>				
					</view>
				</scroll-view>
			</swiper-item>
		</swiper>
		
		
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex';
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import empty from "@/components/empty";
	export default {
		components: {
			uniLoadMore,
			empty
		},
		data() {
			return {
				tabCurrentIndex: 0,
				navList: [{
						state: 0,
						text: '全部',
						loadingType: 'more',
						orderList: []
					},
					{
						state: 1,
						text: '待付款',
						loadingType: 'more',
						orderList: []
					},
					{
						state: 2,
						text: '售后/退款',
						loadingType: 'more',
						orderList: []
					},
					{
						state: 3,
						text: '待出行',
						loadingType: 'more',
						orderList: []
					}
				],
			};
		},

		onLoad() {
			
			
		},
		onShow(){
			if(!this.$store.state.hasLogin){
				console.log("pppp")
			}
			else{
				this.createOrder()
			}
		},
		computed:{
			...mapState(['hasLogin'])
		},
		methods: {
			//获取订单列表
			loadData(source) {
				//这里是将订单挂载到tab列表下
				let index = this.tabCurrentIndex;
				let navItem = this.navList[index];
				let state = navItem.state;

				if (source === 'tabChange' && navItem.loaded === true) {
					//tab切换只有第一次需要加载数据
					return;
				}
				if (navItem.loadingType === 'loading') {
					//防止重复加载
					return;
				}


				navItem.loadingType = 'loading';

			},
			buy(id,sum_price){
				console.log(id,sum_price)
				uni.redirectTo({
					url: '/pages/money/pay?'+"id="+id+"&"+"sum_price="+sum_price
				})
			},
			async createOrder() {
				let id = this.$store.state.userInfo.id
				const sendData = {
					id
				};
				console.log(sendData)
				const res = await this.$myRequest({
					url: 'http://127.0.0.1:8000/getOrderInfo',
					data: sendData
				});
				console.log(res.data)
				let dates = res.data
				this.navList[0].orderList = dates.slice(0, 1)
				this.navList[1].orderList = dates.slice(1, 2)
				this.navList[2].orderList = dates.slice(2, 3)
				// this.navList
				console.log(this.navList[0].orderList)

			},
			//swiper 切换
			changeTab(e) {
				this.tabCurrentIndex = e.target.current;
				this.loadData('tabChange');
			},
			//顶部tab点击
			tabClick(index) {
				this.tabCurrentIndex = index;
				console.log(this.tabCurrentIndex)
			},
			tologin(){
				console.log("login")
				uni.navigateTo({
					url:'../login/login'
				})  
			}
		},
	}
</script>

<style lang="scss">
	page,
	// .container{
	// 	padding-bottom: 134upx;
	// 	/* 空白页 */
	// 	.empty{
	// 		position:fixed;
	// 		left: 0;
	// 		top:0;
	// 		width: 100%;
	// 		height: 100vh;
	// 		padding-bottom:100upx;
	// 		display:flex;
	// 		justify-content: center;
	// 		flex-direction: column;
	// 		align-items:center;
	// 		background: #fff;
	// 		image{
	// 			width: 240upx;
	// 			height: 160upx;
	// 			margin-bottom:30upx;
	// 		}
	// 		.empty-tips{
	// 			display:flex;
	// 			font-size: $font-sm+2upx;
	// 			color: $font-color-disabled;
	// 			.navigator{
	// 				color: $uni-color-primary;
	// 				margin-left: 16upx;
	// 			}
	// 		}
	// 	}
	// }
	.content {
		background: $page-color-base;
		height: 100%;
	}

	.swiper-box {
		height: calc(100% - 40px);
	}

	.list-scroll-content {
		height: 100%;
	}
	.navbar {
		display: flex;
		height: 40px;
		padding: 0 5px;
		background: #fff;
		box-shadow: 0 1px 5px rgba(0, 0, 0, .06);
		position: relative;
		z-index: 10;

		.nav-item {
			flex: 1;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100%;
			font-size: 15px;
			color: $font-color-dark;
			position: relative;

			&.current {
				color: $base-color;

				&:after {
					content: '';
					position: absolute;
					left: 50%;
					bottom: 0;
					transform: translateX(-50%);
					width: 44px;
					height: 0;
					border-bottom: 2px solid $base-color;
				}
			}
		}
	}

	.uni-swiper-item {
		height: auto;
	}

	.order-item {
		display: flex;
		flex-direction: column;
		padding-left: 30upx;
		background: #fff;
		margin-top: 16upx;

		.i-top {
			display: flex;
			align-items: center;
			height: 80upx;
			padding-right: 30upx;
			font-size: $font-base;
			color: $font-color-dark;
			position: relative;

			.time {
				flex: 1;
			}

			.state {
				color: $base-color;
			}

			.del-btn {
				padding: 10upx 0 10upx 36upx;
				font-size: $font-lg;
				color: $font-color-light;
				position: relative;

				&:after {
					content: '';
					width: 0;
					height: 30upx;
					border-left: 1px solid $border-color-dark;
					position: absolute;
					left: 20upx;
					top: 50%;
					transform: translateY(-50%);
				}
			}
		}

		/* 多条商品 */
		.goods-box {
			height: 160upx;
			padding: 20upx 0;
			white-space: nowrap;

			.goods-item {
				width: 120upx;
				height: 120upx;
				display: inline-block;
				margin-right: 24upx;
			}

			.goods-img {
				display: block;
				width: 100%;
				height: 100%;
			}
		}

		/* 单条商品 */
		.goods-box-single {
			display: flex;
			padding: 20upx 0;

			.goods-img {
				display: block;
				width: 120upx;
				height: 120upx;
			}

			.right {
				flex: 1;
				display: flex;
				flex-direction: column;
				padding: 0 30upx 0 24upx;
				overflow: hidden;

				.title {
					font-size: $font-base + 2upx;
					color: $font-color-dark;
					line-height: 1;
				}

				.attr-box {
					font-size: $font-sm + 2upx;
					color: $font-color-light;
					padding: 10upx 12upx;
				}

				.price {
					font-size: $font-base + 2upx;
					color: $font-color-dark;

					&:before {
						content: '￥';
						font-size: $font-sm;
						margin: 0 2upx 0 8upx;
					}
				}
			}
		}

		.price-box {
			display: flex;
			justify-content: flex-end;
			align-items: baseline;
			padding: 20upx 30upx;
			font-size: $font-sm + 2upx;
			color: $font-color-light;

			.num {
				margin: 0 8upx;
				color: $font-color-dark;
			}

			.price {
				font-size: $font-lg;
				color: $font-color-dark;

				&:before {
					content: '￥';
					font-size: $font-sm;
					margin: 0 2upx 0 8upx;
				}
			}
		}

		.action-box {
			display: flex;
			justify-content: flex-end;
			align-items: center;
			height: 100upx;
			position: relative;
			padding-right: 30upx;
		}

		.action-btn {
			width: 160upx;
			height: 60upx;
			margin: 0;
			margin-left: 24upx;
			padding: 0;
			text-align: center;
			line-height: 60upx;
			font-size: $font-sm + 2upx;
			color: $font-color-dark;
			background: #fff;
			border-radius: 100px;

			&:after {
				border-radius: 100px;
			}

			&.recom {
				background: #fff9f9;
				color: $base-color;

				&:after {
					border-color: #f7bcc8;
				}
			}
		}
	}


	/* load-more */
	.uni-load-more {
		display: flex;
		flex-direction: row;
		height: 80upx;
		align-items: center;
		justify-content: center
	}

	.uni-load-more__text {
		font-size: 28upx;
		color: #999
	}

	.uni-load-more__img {
		height: 24px;
		width: 24px;
		margin-right: 10px
	}

	.uni-load-more__img>view {
		position: absolute
	}

	.uni-load-more__img>view view {
		width: 6px;
		height: 2px;
		border-top-left-radius: 1px;
		border-bottom-left-radius: 1px;
		background: #999;
		position: absolute;
		opacity: .2;
		transform-origin: 50%;
		animation: load 1.56s ease infinite
	}

	.uni-load-more__img>view view:nth-child(1) {
		transform: rotate(90deg);
		top: 2px;
		left: 9px
	}

	.uni-load-more__img>view view:nth-child(2) {
		transform: rotate(180deg);
		top: 11px;
		right: 0
	}

	.uni-load-more__img>view view:nth-child(3) {
		transform: rotate(270deg);
		bottom: 2px;
		left: 9px
	}

	.uni-load-more__img>view view:nth-child(4) {
		top: 11px;
		left: 0
	}

	.load1,
	.load2,
	.load3 {
		height: 24px;
		width: 24px
	}

	.load2 {
		transform: rotate(30deg)
	}

	.load3 {
		transform: rotate(60deg)
	}

	.load1 view:nth-child(1) {
		animation-delay: 0s
	}

	.load2 view:nth-child(1) {
		animation-delay: .13s
	}

	.load3 view:nth-child(1) {
		animation-delay: .26s
	}

	.load1 view:nth-child(2) {
		animation-delay: .39s
	}

	.load2 view:nth-child(2) {
		animation-delay: .52s
	}

	.load3 view:nth-child(2) {
		animation-delay: .65s
	}

	.load1 view:nth-child(3) {
		animation-delay: .78s
	}

	.load2 view:nth-child(3) {
		animation-delay: .91s
	}

	.load3 view:nth-child(3) {
		animation-delay: 1.04s
	}

	.load1 view:nth-child(4) {
		animation-delay: 1.17s
	}

	.load2 view:nth-child(4) {
		animation-delay: 1.3s
	}

	.load3 view:nth-child(4) {
		animation-delay: 1.43s
	}

	@-webkit-keyframes load {
		0% {
			opacity: 1
		}

		100% {
			opacity: .2
		}
	}

	.list_air {
		width: 97%;
		height: 300rpx;
		background-color: #EEEEEE;
		border-radius: 10rpx;
		margin: 10rpx 15rpx 0 0;
	}

	.air_info {
		height: 200rpx;
		/* background-color: #4399FC; */
		width: 100%;
		border-radius: 15rpx;
	}

	.other_fun {
		height: 100rpx;
		width: 100%;
	}

	.left_con {
		width: 75%;
		height: 200rpx;
		/* background-color: #606266; */
		float: left;
	}

	.right_con {
		width: 25%;
		height: 200rpx;
		float: right;
	}

	.time_info {
		height: 120rpx;
		width: 100%;
		/* background-color: #FA436A; */
	}

	.air_content {
		height: 80rpx;
		width: 100%;
		text-align: center;
	}

	.pirze_info {
		width: 100%;
		height: 140rpx;
		/* background-color: #EEEEEE; */
	}

	.sale_btn {
		width: 100%;
		height: 60rpx;
	}

	.tourism_programme {
		width: 30%;
		height: 100rpx;
		/* background-color: white; */
		float: left;
	}

	.right_fun {
		width: 70%;
		height: 100rpx;
		/* background-color: red; */
		float: right;
	}

	.strategy {
		width: 40%;
		height: 100rpx;
		/* background-color: #DD524D; */
		float: left;
	}

	.road_map {
		width: 60%;
		height: 100rpx;
		float: right;

		/* background-color: #4CD964; */
	}

	.start_time {
		width: 30%;
		float: left;
	}

	.float_time {
		width: 70%;
		float: right;
	}

	.img {
		width: 50%;
		float: left;
	}

	.stop_time {
		width: 50%;
		float: right;
	}

	.content_text {
		font-size: 25rpx;
		padding-left: -10rpx;
	}
</style>
