<template>
	<view class="container">
		<view class="title_airport">
			<text>标题</text>
		</view>
		<view class="search_con">
			<view class="taber">
				<view class="sale_filght">订购机票</view>
			</view>
			<form @submit="formSubmit">
				<view class="starting_point">
					<input class="start" type="text" v-model="start_place"  name="start_place">
				</view>
				<view class="stop_point">
					<input class="stop" type="text" v-model="stop_place" name="stop_place">
				</view>
				<view>
					<button class="but_sub" form-type="submit" type="primary">提交</button>
				</view>
			</form>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				dates: '',
				start_place:"海南",
				stop_place:"北京"
			};
		},
		onLoad() {
			this.loaddata()
		},
		methods: {
			loaddata() {
				// uni.request({
				// 	url: 'http://127.0.0.1:8000/test_app/test1',
				// 	success(res) {
				// 		this.dates = res.data
				// 		console.log(res.data)
				// 	}
				// })
			},
			formSubmit: function(e) {
				console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
				var formdata = e.detail.value
				console.log(formdata.start_place)
				// start_place=formdata["start_place"]
				// stop_place=formdata["stop_place"]
				console.log(this.start_place)
				console.log(this.stop_place)
				uni.showModal({
					content: '表单数据内容：' + JSON.stringify(formdata),
					showCancel: false
				});
				uni.navigateTo({
				    url: '../detail/detail?'+'start_place='+formdata.start_place+'&'+'stop_place='+formdata.stop_place,
					success() {
						console.log("okk")
					}
				});
			},
		},
		// #ifndef MP
		// 标题栏input搜索框点击
		onNavigationBarSearchInputClicked: async function(e) {
			this.$api.msg('点击了搜索框');
		}
		// #endif
	}
</script>

<style lang="scss">
	/* #ifdef MP */
	.mp-search-box {
		position: absolute;
		left: 0;
		top: 30upx;
		z-index: 9999;
		width: 100%;
		padding: 0 80upx;

		.ser-input {
			flex: 1;
			height: 56upx;
			line-height: 56upx;
			text-align: center;
			font-size: 28upx;
			color: $font-color-base;
			border-radius: 20px;
			background: rgba(255, 255, 255, .6);
		}
	}

	page {
		.cate-section {
			position: relative;
			z-index: 5;
			border-radius: 16upx 16upx 0 0;
			margin-top: -20upx;
		}

		.carousel-section {
			padding: 0;

			.titleNview-placing {
				padding-top: 0;
				height: 0;
			}

			.carousel {
				.carousel-item {
					padding: 0;
				}
			}

			.swiper-dots {
				left: 45upx;
				bottom: 40upx;
			}
		}
	}

	/* #endif */
	page {
		background: #f5f5f5;
	}

	.m-t {
		margin-top: 16upx;
	}

	.title_airport {
		margin-top: 20rpx;
		width: 100%;
		height: 50rpx;
		text-align: center;
	}

	.search {
		margin: 100rpx 200rpx 0 50rpx;
		border-radius: 40rpx;
		height: 80rpx;
		color: $font-color-base;
		background: rgba(255, 255, 255, .6);
		line-height: 60upx;
		text-align: center;
	}

	.search_con {
		width: 100%;
		height: 800rpx;
		background-color: red;
		margin-top: 50rpx;
		text-align: center;
	}

	.taber {
		width: 100%;
		height: 100rpx;

	}

	.sale_filght {
		height: 80rpx;
		background-color: #F0AD4E;
		text-align: center;
		line-height: 80rpx;
	}

	.starting_point {
		width: 50%;
		height: 200rpx;
		background-color: blue;
		float: left;
	}

	.start {
		background-color: pink;
		height: 100rpx;
		border-radius: 15rpx;
		margin: 10px;
	}

	.stop_point {
		width: 50%;
		height: 200rpx;
		background-color: white;
		float: right;
	}

	.stop {
		background-color: pink;
		height: 100rpx;
		border-radius: 15rpx;
		margin: 10px;
	}

	.but_sub {
		margin: 30rpx;
		margin-top: 250rpx;
	}
</style>
