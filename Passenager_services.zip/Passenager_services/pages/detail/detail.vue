.<template>
	<view>
		<view style="margin-top: 50rpx;">
			<view class='list_air' v-for="(item, index) in air_info" :key="item.id">
				<view class="air_info">
					<view class="left_con">
						<view class="time_info">
							<view class="start_time">
								<view style="margin-left: 10rpx;font-size: 30rpx;padding-top: 20rpx;">
									<text style="padding-left: 15rpx;">{{item.start_time}}</text>
									<view>{{item.start_airport}}</view>
								</view>
							</view>
							<view class="float_time">
								<view class="img">
									<view style="margin-left: 10rpx;font-size: 30rpx;padding-top: 20rpx;">
										<view style="padding-left: 20rpx;">{{item.time_sub}}</view>
										<text>--------></text>
									</view>
								</view>
								<view class="stop_time">
									<view style="margin-left: 10rpx;font-size: 30rpx;padding-top: 20rpx;">

										<text style="padding-left: 15rpx;">{{item.stop_time}}</text>
										<view>{{item.stop_airport}}</view>
									</view>
								</view>
							</view>
						</view>
						<view class="air_content">
							<text style="" class="content_text">{{item.air_no_company}} | {{item.air_type}}</text>
						</view>
					</view>
					<view class="right_con">
						<view class="pirze_info">
							<view style="padding-top: 30rpx;text-align: center;">￥{{item.price}}</view>
							<view style="text-align: center;">{{item.position}}</view>
						</view>
						<view class="sale_btn">
							<view style="padding-top: 5rpx;text-align: center;">
								<button style="height: 50rpx;font-size: 20rpx;line-height: 50rpx;" type="warn" @click="buy(item.id)">立即购买</button>
							</view>
						</view>
					</view>
				</view>
				<view class="other_fun">
					<view class="tourism_programme">
						<view style="width: 100%;height: 80rpx;line-height: 80rpx;padding-left: 10rpx;border-radius: 40rpx;padding-top: 10rpx;padding-right: 10rpx;">
							<button style="text-align: center;font-size: 25rpx;">旅游方案</button>
						</view>
					</view>
					<view class="right_fun">
						<view class="strategy">
							<view style="width: 100%;height: 80rpx;line-height: 80rpx;padding-left: 10rpx;border-radius: 40rpx;padding-top: 10rpx;padding-right: 10rpx;">
								<button style="text-align: center;font-size: 25rpx;">攻略</button>
							</view>
						</view>
						<view class="road_map">
							<view style="width: 100%;height: 80rpx;line-height: 80rpx;padding-left: 10rpx;border-radius: 40rpx;padding-top: 10rpx;padding-right: 10rpx;">
								<button style="text-align: center;font-size: 25rpx;">地图</button>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				air_info: [],
				flag:null
			}
		},
		methods:{
			buy(id){
				console.log(id)
				uni.navigateTo({
					url: '/pages/order/createorder'+'?'+'id='+id+"&"+'flag='+this.flag
				})
			}
		},
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
		    let this_=this;
			console.log(option)
			let stop_place = option.stop_place
			let start_place = option.start_place
		    let flag=option.flag
			let day=option.day
			this_.flag=flag
			console.log(day)
			uni.request({
				url: 'http://127.0.0.1:8000/test',
				data: {
					start_place: start_place,
					stop_place: stop_place,
					flag:flag,
					day:day
				},
				success:function(res) {
					let dates=res.data;
					console.log(res.data);
					this_.air_info=res.data
				}
			})
			
		}
	}
</script>

<style>
	.list_air {
		width: 97%;
		height: 300rpx;
		background-color: #EEEEEE;
		border-radius: 10rpx;
		margin: 10rpx 15rpx 0 10rpx;
	}

	.air_info {
		height: 200rpx;
		/* background-color: #4399FC; */
		width: 100%;
		border-radius: 15rpx;
	}

	.other_fun {
		height: 100rpx;
		width: 100%;
	}

	.left_con {
		width: 75%;
		height: 200rpx;
		/* background-color: #606266; */
		float: left;
	}

	.right_con {
		width: 25%;
		height: 200rpx;
		float: right;
	}

	.time_info {
		height: 120rpx;
		width: 100%;
		/* background-color: #FA436A; */
	}

	.air_content {
		height: 80rpx;
		width: 100%;
		text-align: center;
	}

	.pirze_info {
		width: 100%;
		height: 140rpx;
		/* background-color: #EEEEEE; */
	}

	.sale_btn {
		width: 100%;
		height: 60rpx;
	}

	.tourism_programme {
		width: 30%;
		height: 100rpx;
		/* background-color: white; */
		float: left;
	}

	.right_fun {
		width: 70%;
		height: 100rpx;
		/* background-color: red; */
		float: right;
	}

	.strategy {
		width: 40%;
		height: 100rpx;
		/* background-color: #DD524D; */
		float: left;
	}

	.road_map {
		width: 60%;
		height: 100rpx;
		float: right;

		/* background-color: #4CD964; */
	}

	.start_time {
		width: 30%;
		float: left;
	}

	.float_time {
		width: 70%;
		float: right;
	}

	.img {
		width: 50%;
		float: left;
	}

	.stop_time {
		width: 50%;
		float: right;
	}

	.content_text {
		font-size: 25rpx;
		padding-left: -10rpx;
	}
</style>
