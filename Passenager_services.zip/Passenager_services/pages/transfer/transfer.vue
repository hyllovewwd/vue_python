<template>
	<view>
		dianj
		<Datecon :class="{active: show}" @confirm="confirm" @cancel="show=false"></Datecon>
	</view>
</template>

<script>
	import Datecon from '../../component/birth-date-plug/index.vue'
	export default {
		data() {
			return {
				show: false,
			}
		},
		components: {
			Datecon
		},
		methods: {
			confirm(date) {
				this.show = false;
				this.birth = date;
			}
		}
	}
</script>

<style>
</style>
